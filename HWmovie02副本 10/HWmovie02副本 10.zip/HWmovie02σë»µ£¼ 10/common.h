//
//  common.h
//  HWmovie
//
//  Created by Mac on 15/7/20.
//  Copyright (c) 2015年 杨梦佳. All rights reserved.
//

#ifndef HWmovie_common_h
#define HWmovie_common_h

#define kwidth   ([UIScreen mainScreen].bounds.size.width)
#define kheight  ([UIScreen mainScreen].bounds.size.height)

#define navKheight 64
#define tabBarKheight 49


#endif
