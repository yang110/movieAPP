//
//  StartViewController.m
//  HWmovie
//
//  Created by Mac on 15/7/27.
//  Copyright (c) 2015年 杨梦佳. All rights reserved.
//

#import "StartViewController.h"
#import "UIViewExt.h"
#import "MyTabBarController.h"
@interface StartViewController ()
{
    int kkk;
    
}
@end

@implementation StartViewController


-(instancetype)init
{
    self=[super init];
    
    if (self) {
        
    
    }
    return self;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.view.backgroundColor=[UIColor whiteColor];
    
    _array=[[NSMutableArray alloc]init];
    int k=1;
    CGFloat kkkkWidth=self.view.width/4;
    CGFloat kkkkHeight=self.view.height/6;
    for (int i=0; i<6; i++)
    {
        for (int j=0; j<4; j++)
        {
            UIImageView *imageView=[[UIImageView alloc]initWithImage:[UIImage imageNamed: [NSString stringWithFormat:@"%d",k++]]];
            imageView.frame=CGRectMake(kkkkWidth*j, kkkkHeight*i,kkkkWidth ,kkkkHeight );
            [_array addObject:imageView];
            [self.view addSubview:imageView];
            
            imageView.alpha=0;
            
        }
    }


    [self start];
    
    
    
    
    
}

-(void)start
{
    
    
    UIImageView *imageView=_array[kkk];
    
    kkk++;
    
    if (kkk==24) {
        
        
        
        UIWindow *window=self.view.window;
        
        
            MyTabBarController  *myTabBar=[[MyTabBarController alloc]init];
            window.rootViewController=myTabBar;
        
        
        
        return;
        
    }
    
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    
    imageView.alpha=1;
    
    
    [UIView commitAnimations];

    
    [self performSelector:@selector(start) withObject:self afterDelay:0.5];
    
    
}










@end
