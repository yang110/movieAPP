//
//  MoreModal.h
//  HWmovie
//
//  Created by Mac on 15/7/22.
//  Copyright (c) 2015年 杨梦佳. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MoreModal : NSObject



@property NSString *image;
@property NSString *text1;



@end
