//
//  StarView.h
//  HWmovie
//
//  Created by Mac on 15/7/21.
//  Copyright (c) 2015年 杨梦佳. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIViewExt.h"

@interface StarView : UIView
{
    UIView *_yellowView;
    UIView *_grayView;
}
@property (nonatomic) float average;


@end
