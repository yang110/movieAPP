//
//  IndexCollectionView.h
//  HWmovie
//
//  Created by Mac on 15/7/25.
//  Copyright (c) 2015年 杨梦佳. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseCollectionView.h"
@interface IndexCollectionView : BaseCollectionView 
@end
