//
//  CinemaModal.m
//  HWmovie
//
//  Created by Mac on 15/7/22.
//  Copyright (c) 2015年 杨梦佳. All rights reserved.
//

#import "CinemaModal.h"

@implementation CinemaModal

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
