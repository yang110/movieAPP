//
//  TopModal.m
//  HWmovie
//
//  Created by Mac on 15/7/21.
//  Copyright (c) 2015年 杨梦佳. All rights reserved.
//

#import "TopModal.h"

@implementation TopModal

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
