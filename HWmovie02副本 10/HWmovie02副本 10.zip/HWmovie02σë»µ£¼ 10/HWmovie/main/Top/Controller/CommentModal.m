//
//  CommentModal.m
//  HWmovie
//
//  Created by Mac on 15/7/27.
//  Copyright (c) 2015年 杨梦佳. All rights reserved.
//

#import "CommentModal.h"

@implementation CommentModal

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
    //虽然数据一一对其，不加也没事，但是还是加上吧 习惯了
    
}

@end
