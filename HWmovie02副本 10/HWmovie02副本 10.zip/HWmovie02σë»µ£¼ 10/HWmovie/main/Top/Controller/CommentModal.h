//
//  CommentModal.h
//  HWmovie
//
//  Created by Mac on 15/7/27.
//  Copyright (c) 2015年 杨梦佳. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommentModal : NSObject




@property (nonatomic) NSString *content;
@property (nonatomic) NSString *nickname;
@property (nonatomic) NSString *rating;
@property (nonatomic) NSString *userImage;

@end
